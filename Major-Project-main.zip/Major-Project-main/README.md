# Major-Project
ScrapEasy Website
https://Scrapeasy.sal-sabeel.com
